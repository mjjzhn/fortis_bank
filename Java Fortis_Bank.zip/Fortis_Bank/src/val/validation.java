package val;

import java.util.ArrayList;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import fortisBank.Account;
import fortisBank.Customer;
import fortisBank.Transaction;;

public class validation {
	private static final String namePat = "^([A-Z]{1}[a-z]*\\s+)+$";
	private static final String idPat = "^[0-9]+$";
	private static final String pinPat = "^[0-9]{5}$";
	public static boolean valName(String c) {
		Pattern p = Pattern.compile(namePat);
		Matcher m = p.matcher(c.trim() + " ");
		return m.find();
	}
	public static boolean valId(String c) {
		Pattern p = Pattern.compile(idPat);
		Matcher m = p.matcher(c.trim());
		return m.find();
	}
	public static boolean valPin(String c) {
		Pattern p = Pattern.compile(pinPat);
		Matcher m = p.matcher(c.trim());
		return m.find();
	}
	public static boolean valPassedDate(String y, String m, String d) {
		try {
			int tempy = Integer.parseInt(y.trim());
			Date date = new Date();
			if(tempy < 1900 || tempy > 1900 + date.getYear()) {
				throw new Exception();
			}
			int tempm = Integer.parseInt(m.trim());
			if(tempm < 1 || tempm > 12) {
				throw new Exception();
			}
			int tempd = Integer.parseInt(d.trim());
			if(tempd < 1) {
				throw new Exception();
			}
			switch(tempm) {
			case 1:
			case 3:
			case 5:
			case 7:
			case 8:
			case 10:
			case 12:
				if(tempd > 31) {
					throw new Exception();
				}
				break;
			case 4:
			case 6:
			case 9:
			case 11:
				if(tempd > 30) {
					throw new Exception();
				}
				break;
			case 2:
				if(tempy%4 == 0) {
					if(tempd > 29) {
						throw new Exception();
					}
				}else {
					if(tempd > 28) {
						throw new Exception();
					}
				}
				break;
			}
		}catch(Exception e) {
			return false;
		}
		return true;
	}
	public static boolean valDupCustomerId(String c, ArrayList<Customer> list) {
		for(Customer i : list) {
			if(i.ID() == c) {
				return true;
			}
		}
		return false;
	}
	public static boolean valDupAccountId(String c, ArrayList<Account> list) {
		for(Account i : list) {
			if(i.Number() == c) {
				return true;
			}
		}
		return false;
	}
	public static boolean valDupTransactionId(String c, ArrayList<Transaction> list) {
		for(Transaction i : list) {
			if(i.Number() == c) {
				return true;
			}
		}
		return false;
	}
	public static boolean valPosDouble(String c) {
		try {
			double d = Double.parseDouble(c);
			if(d < 0) {
				return false;
			}
			return true;
		}catch(Exception e) {
			return false;
		}
	}
}
