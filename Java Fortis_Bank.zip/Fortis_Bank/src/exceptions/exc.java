package exceptions;

public class exc extends Exception {
	private static String message = "Exception Throw";
	public exc() {
		super(message);
	}
	public exc(exList ex) {
		super(ex.toString());
	}
}
