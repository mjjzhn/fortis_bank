package exceptions;

public enum exList {
	WrongIdFormat,DuplicatedId,NotValidNumberWithDecimal,NotValidPin,NotValidName,CustomerAlreadyHasThisTypeOfAccount,PoorGuyNotEnoughMoney
}
