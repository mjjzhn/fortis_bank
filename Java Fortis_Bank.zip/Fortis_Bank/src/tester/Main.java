package tester;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

import fortisBank.Account;
import fortisBank.CheckingAccount;
import fortisBank.Customer;
import fortisBank.SavingAccount;
import fortisBank.Transaction;
import fortisBank.TransactionType;
import dataAccess.FileHandler;
import exceptions.exList;
import exceptions.exc;

public class Main {
	@SuppressWarnings("unchecked")
	public static void main(String[] args) throws IOException, ClassNotFoundException, exc {
		

		int choice;
		boolean getout = false;
		ArrayList<Customer> cusList = new ArrayList<Customer>();
		{
			File tempFile = new File("dataFile.ser");
			if(tempFile.exists()) {
				cusList = (ArrayList<Customer>)(FileHandler.ReadFrom("dataFile.ser"));
			}
		}
		//System.out.println(cusList.get(0).Accounts().get(0).toString());
		Scanner sc = new Scanner(System.in);
		while (!getout) {
			System.out.println("--------------------------");
			System.out.println("TASK :");
			System.out.println("1. Create New Customer");
			System.out.println("2. Manage a specific Customer");
			System.out.println("3. Show all Customer");
			System.out.println("4. Exit");
			System.out.print("Your Choice : ");
			try {
				String ans = sc.nextLine().trim();
				choice = Integer.parseInt(ans);
				if (choice > 4 || choice < 1) {
					throw new NumberFormatException();
				}
			} catch (NumberFormatException e) {
				System.out.println("Please input a valid choice");
				continue;
			}

			switch (choice) {
			case 1:
				System.out.println("New Customer:");
				cusList.add(Customer.NewCustomer(cusList, sc));
				break;
			case 2:
				System.out.println("Manage Customer");
				System.out.println("Customer ID : ");
				String cid = sc.nextLine().trim();
				for(Customer c : cusList) {
					if(c.ID().equals(cid)) {
						c.ManageCustomer(sc);
						break;
					}
				}
				break;
			case 3:
				System.out.println("ALL Customers");
				for (Customer c : cusList) {
					System.out.println(c.toString());
				}
				break;
			case 4:
				getout = true;
				break;
			}

		}
		sc.close();
		FileHandler.WriteTo("dataFile.ser", cusList);
		System.out.println("out");
	}

}
