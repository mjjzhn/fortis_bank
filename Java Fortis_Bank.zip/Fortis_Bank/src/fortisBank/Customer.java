package fortisBank;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Scanner;

import exceptions.exList;
import exceptions.exc;
import val.validation;

public class Customer implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String id, fn, ln;
	private ArrayList<Account> accounts;
	private boolean alive;

	public String ID() {
		return this.id;
	}

	public void ID(String c) throws exc {
		this.id = c;
	}

	public String FirstName() {
		return this.fn;
	}

	public void FirstName(String c) {
		this.fn = c;
	}

	public String LastName() {
		return this.ln;
	}

	public void LastName(String c) {
		this.ln = c;
	}

	public ArrayList<Account> Accounts() {
		return this.accounts;
	}

	public void Accounts(ArrayList<Account> c) {
		this.accounts = c;
	}

	public boolean Alive() {
		return this.alive;
	}

	public void Alive(boolean c) {
		this.alive = c;
	}

	public Customer(Account ca) {
		this.id = "0000";
		this.fn = "undefined";
		this.ln = "undefined";
		this.accounts = new ArrayList<Account>();
		this.accounts.add(ca);
		this.alive = true;
	}

	public Customer(String id, String fn, String ln, Account ca) {
		this.id = id;
		this.fn = fn;
		this.ln = ln;
		this.accounts = new ArrayList<Account>();
		this.accounts.add(ca);
		this.alive = true;
	}

	public String toString() {
		return "id=" + this.id + ", FirstName=" + this.fn + ", LastName=" + this.ln;
	}

	public void OpenAccount(Account acc) {
		for (Account a : this.accounts) {
			if (a.Type() == acc.Type()) {
				System.out.println("You already have a " + acc.Type().toString() + " account, OPERATION FAILED");
				return;
			}
		}
		this.accounts.add(acc);
		System.out.println("A " + acc.Type().toString() + " account is added to you, OPERATION SUCCESS");
	}

	public void DeleteAccount(Scanner sc) {
		boolean getout = false;
		while (!getout) {
			int choice = 0;
			System.out.println("--------------------------");
			System.out.println("Please select the account ypu want to Delete");
			System.out.println("1. Saving");
			System.out.println("2. Credit");
			System.out.println("3. Currency");
			System.out.println("4. Back");
			System.out.println("Your Choice : ");
			try {
				choice = Integer.parseInt(sc.nextLine().trim());
				if (choice > 4 || choice < 1) {
					throw new NumberFormatException();
				}
			} catch (NumberFormatException e) {
				System.out.println("Please input a valid choice");
				continue;
			}
			switch(choice) {
			case 1:
				this.DeleteAccount(AccountType.Saving, sc);
				break;
			case 2:
				this.DeleteAccount(AccountType.Credit, sc);
				break;
			case 3:
				this.DeleteAccount(AccountType.Currency, sc);
				break;
			case 4:
				getout = true;
				break;
			}
			getout = true;
		}
	}

	public void DeleteAccount(AccountType t, Scanner sc) {
		if (t == AccountType.Checking) {
			System.out.println("You cannot DELETE the " + t.toString() + " account, OPERATION FAILED");
			return;
		}
		int index = -1;
		for (Account a : this.accounts) {
			if (a.Type() == t) {
				System.out.println("Are you sure to DELETE the " + t.toString() + " account? Y/N");
				if (sc.nextLine().trim().toUpperCase().equals("Y")) {
					index = this.accounts.indexOf(a);
					break;
				} else {
					System.out.println("Operation Cancelled, OPERATION FAILED");
					return;
				}
			}
		}
		if (index != -1) {
			this.accounts.remove(index);
			System.out.println("The " + t.toString() + " account is DELETED, OPERATION SUCCESS");
			return;
		}
		System.out.println("No " + t.toString() + " account is found, OPERATION FAILED");
	}

	public static Customer NewCustomer(ArrayList<Customer> cusList, Scanner sc) {
		int num = cusList.size();
		while (true) {
			try {
				if (!validation.valId(String.valueOf(num))) {
					throw new exc(exList.WrongIdFormat);
				} else if (validation.valDupCustomerId(String.valueOf(num), cusList)) {
					throw new exc(exList.DuplicatedId);
				}
				break;
			} catch (Exception e) {
				num++;
			}
		}
		String number = String.valueOf(num);
		String fn = "";
		String ln = "";
		Account acc = new Account();
		int count = 0;
		boolean getout = false;
		// Scanner sc = new Scanner(System.in);
		String inpt;
		System.out.println("Customer ID is : " + number);
		while (!getout) {
			try {
				switch (count) {
				case 0:
					System.out.println("Customer First Name : ");
					inpt = sc.nextLine().trim();
					if (!validation.valName(inpt)) {
						throw new exc(exList.NotValidName);
					}
					fn = inpt;
					count++;
				case 1:
					System.out.println("Customer Last Name : ");
					inpt = sc.nextLine().trim();
					if (!validation.valName(inpt)) {
						throw new exc(exList.NotValidName);
					}
					ln = inpt;
					count++;
				case 2:
					System.out.println("New Customer must at least have a checking account ");
					acc = CheckingAccount.NewCheckingAccount(new ArrayList<Account>(), sc);
					getout = true;
					break;
				}
			} catch (Exception e) {
				System.out.println(e);
			}
		}
		// sc.close();
		return new Customer(number, fn, ln, acc);

	}

	public void ManageCustomer(Scanner sc) {
		boolean getout = false;
		while (!getout) {
			int choice = 0;
			System.out.println("--------------------------");
			System.out.println("Manage Customer " + this.id);
			System.out.println("1. Change Customer First Name");
			System.out.println("2. Change Customer Last Name");
			System.out.println("3. Show Customer Accounts");
			System.out.println("4. Add New Account");
			System.out.println("5. Manage Account");
			System.out.println("6. Show myself");
			System.out.println("7. Delete Account");
			System.out.println("8. Go to Previous Menu");
			System.out.println("Choice : ");
			try {
				choice = Integer.parseInt(sc.nextLine().trim());
				if (choice > 8 || choice < 1) {
					throw new NumberFormatException();
				}
			} catch (NumberFormatException e) {
				System.out.println("Please input a valid choice");
				continue;
			}
			String inpt = "";
			try {
				switch (choice) {
				case 1:
					System.out.println("New First Name :");
					inpt = sc.nextLine().trim();
					if (!validation.valName(inpt)) {
						throw new exc(exList.NotValidName);
					}
					this.fn = inpt;
					break;
				case 2:
					System.out.println("New Last Name :");
					inpt = sc.nextLine().trim();
					if (!validation.valName(inpt)) {
						throw new exc(exList.NotValidName);
					}
					this.ln = inpt;
					break;
				case 3:
					System.out.println("Customer's Accounts");
					for (Account acc : this.accounts) {
						System.out.println(acc.toString());
					}
					break;
				case 4:
					boolean subGetout = false;
					while (!subGetout) {
						System.out.println("Please choose an account type :");
						System.out.println("1. Saving");
						System.out.println("2. Credit");
						System.out.println("3. Currency");
						System.out.println("4. Go to Previous");
						System.out.println("Please Choose : ");
						int subChoice = 0;
						try {
							subChoice = Integer.parseInt(sc.nextLine().trim());
						} catch (NumberFormatException e) {
							System.out.println("Please input a valid choice");
							continue;
						}
						try {
							switch (subChoice) {
							case 1:
								for (Account acc : this.accounts) {
									if (acc.Type() == AccountType.Saving) {
										throw new exc(exList.CustomerAlreadyHasThisTypeOfAccount);
									}
								}
								this.accounts.add(SavingAccount.NewSavingAccount(this.accounts, sc));
								System.out.println("New Saving Account Added To Customer");
								break;
							case 2:
								for (Account acc : this.accounts) {
									if (acc.Type() == AccountType.Credit) {
										throw new exc(exList.CustomerAlreadyHasThisTypeOfAccount);
									}
								}
								this.accounts.add(Account.NewAccount(this.accounts, sc, AccountType.Credit));
								System.out.println("New Credit Account Added To Customer");
								break;
							case 3:
								for (Account acc : this.accounts) {
									if (acc.Type() == AccountType.Currency) {
										throw new exc(exList.CustomerAlreadyHasThisTypeOfAccount);
									}
								}
								this.accounts.add(Account.NewAccount(this.accounts, sc, AccountType.Currency));
								System.out.println("New Currency Account Added To Customer");
								break;
							case 4:
								subGetout = true;
								break;
							}
							subGetout = true;
						} catch (Exception e) {
							System.out.println(e);
						}
					}
					break;
				case 5:
					System.out.println("Manage Account");
					System.out.println("Account Number : ");
					String accid = sc.nextLine().trim();
					for (Account acc : this.accounts) {
						if (acc.Number().equals(accid)) {
							acc.ManageAccount(sc);
							break;
						}
					}
					break;
				case 6:
					System.out.println(this.toString());
					break;
				case 7:
					this.DeleteAccount(sc);
					break;
				case 8:
					getout = true;
					break;
				}
			} catch (Exception e) {
				System.out.println(e);
			}
		}
	}
}
