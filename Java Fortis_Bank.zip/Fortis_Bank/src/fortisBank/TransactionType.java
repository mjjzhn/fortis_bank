package fortisBank;

public enum TransactionType {
	Deposite, Withdraw;
	public String toString() {
		if(this == Deposite) {
			return "Deposite";
		}else if(this == Withdraw) {
			return "Withdraw";
		}else {
			return "undefined";
		}
	}
}
