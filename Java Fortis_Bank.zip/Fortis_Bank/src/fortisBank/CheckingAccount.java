package fortisBank;

import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

import exceptions.exList;
import exceptions.exc;
import val.validation;

public class CheckingAccount extends Account {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Double xFees;
	private int freeTransLimit;

	public CheckingAccount(String number, String pin, Date openDate, Double balance) {
		super(number, pin, AccountType.Checking, openDate, balance);
		this.xFees = 1.00;
		this.freeTransLimit = 4;
	}
	public CheckingAccount() {
		super();
	}

	public Double XFees() {
		return this.xFees;
	}

	public void XFees(Double c) {
		this.xFees = c;
	}

	public int FreeTransLimit() {
		return this.freeTransLimit;
	}

	public void FreeTransLimit(int c) {
		this.freeTransLimit = c;
	}

	public String toString() {
		return super.toString() + ", xFees=" + this.xFees + ", FreeTransLimit=" + this.freeTransLimit;
	}

	public static CheckingAccount NewCheckingAccount(ArrayList<Account> accList, Scanner sc) {
		Account tempAcc = Account.NewAccount(accList, sc, AccountType.Checking);
		return new CheckingAccount(tempAcc.Number(), tempAcc.Pin(), tempAcc.OpenDate(), tempAcc.Balance());
	}
}
