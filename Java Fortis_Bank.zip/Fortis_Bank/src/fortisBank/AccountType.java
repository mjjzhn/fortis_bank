package fortisBank;

public enum AccountType {
	Checking, Saving, Credit, Currency;
	public String toString() {
		if(this == Checking) {
			return "Checking";
		}else if(this == Saving) {
			return "Saving";
		}else if(this == Credit) {
			return "Credit";
		}else if(this == Currency) {
			return "Currency";
		}else {
			return "undefined";
		}
	}
}
