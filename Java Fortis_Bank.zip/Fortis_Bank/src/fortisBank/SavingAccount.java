package fortisBank;

import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

public class SavingAccount extends Account {
	private Double xFees, anInter, anGain;

	public SavingAccount(String number, String pin, Date openDate, Double balance) {
		super(number, pin, AccountType.Saving, openDate, balance);
		this.xFees = 1.00;
		this.anInter = 0.04;
		this.anGain = balance * this.anInter;
	}

	public Double XFees() {
		return this.xFees;
	}

	public void XFees(Double c) {
		this.xFees = c;
	}

	public Double AnInter() {
		return this.anInter;
	}

	public void AnInter(Double c) {
		this.anInter = c;
	}

	public Double AnGain() {
		this.anGain = this.anInter * super.Balance();
		return this.anGain;
	}

	public void AnGain(Double c) {
		this.anGain = c;
	}

	public String toString() {
		return super.toString() + ", xFees=" + this.xFees.toString() + ", AnnualInterest=" + this.anInter.toString()
				+ ", AnnualGain=" + this.AnGain().toString();
	}

	public static SavingAccount NewSavingAccount(ArrayList<Account> accList, Scanner sc) {
		Account tempAcc = Account.NewAccount(accList, sc, AccountType.Saving);
		return new SavingAccount(tempAcc.Number(), tempAcc.Pin(), tempAcc.OpenDate(), tempAcc.Balance());
	}

}
