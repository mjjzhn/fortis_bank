package fortisBank;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

import exceptions.exList;
import exceptions.exc;
import val.validation;

public class Account implements Serializable {

	private static final long serialVersionUID = 1L;
	private String number, pin;
	private AccountType type;
	private Date date;
	private Double balance;
	private ArrayList<Transaction> transactions;
	private boolean alive;

	public String Number() {
		return this.number;
	}

	public void Number(String c) {
		this.number = c;
	}

	public String Pin() {
		return this.pin;
	}

	public void Pin(String c) {
		this.pin = c;
	}

	public AccountType Type() {
		return this.type;
	}

	public void Type(AccountType c) {
		this.type = c;
	}

	public Date OpenDate() {
		return this.date;
	}

	public void OpenDate(Date c) {
		this.date = c;
	}

	public Double Balance() {
		return this.balance;
	}

	public void Balance(Double c) {
		this.balance = c;
	}

	public ArrayList<Transaction> ListTrans() {
		return this.transactions;
	}

	public void ListTrans(ArrayList<Transaction> c) {
		this.transactions = c;
	}

	public boolean Alive() {
		return this.alive;
	}

	public void Alive(boolean c) {
		this.alive = c;
	}

	public Account(String number, String pin, AccountType type, Date openDate, Double balance) {
		this.number = number;
		this.pin = pin;
		this.type = type;
		this.date = openDate;
		this.balance = balance;
		this.transactions = new ArrayList<Transaction>();
		this.alive = true;
	}

	public Account() {
		this.alive = true;
	}

	public String toString() {
		return "Number=" + this.number + ", Type=" + this.type + ", OpenDate=" + this.date + ", Balance="
				+ this.balance;
	}

	public static Account NewAccount(ArrayList<Account> accList, Scanner sc, AccountType accType) {
		int num = accList.size();

		while (true) {
			try {
				if (!validation.valId(String.valueOf(num))) {
					throw new exc(exList.WrongIdFormat);
				} else if (validation.valDupAccountId(String.valueOf(num), accList)) {
					throw new exc(exList.DuplicatedId);
				}
				break;
			} catch (Exception e) {
				num++;
			}
		}
		String number = String.valueOf(num);

		String pin = "";
		Date openDate = new Date();
		Double balance = (double) 0;
		int count = 0;
		boolean getout = false;
		String inpt = "";
		System.out.println("The Account number is : " + number);
		while (!getout) {
			try {
				switch (count) {
				case 0:
					System.out.println("Pin : ");
					inpt = sc.nextLine().trim();
					if (!validation.valPin(inpt)) {
						throw new exc(exList.NotValidPin);
					}
					pin = inpt;
					count++;
					System.out.println("Pin=" + pin);
				case 1:
					System.out.println("Balance : ");
					inpt = sc.nextLine().trim();
					if (!validation.valPosDouble(inpt)) {
						throw new exc(exList.NotValidNumberWithDecimal);
					}
					balance = Double.parseDouble(inpt);
					getout = true;
					break;
				}
			} catch (Exception e) {
				System.out.println(e);
			}
		}
		return new Account(number, pin, accType, new Date(openDate.getTime()), balance);

	}

	public void ManageAccount(Scanner sc) {
		boolean getout = false;
		while (!getout) {
			int choice = 0;
			System.out.println("--------------------------");
			System.out.println("Manage Account " + this.number);
			System.out.println("1. Change Pin");
			System.out.println("2. Show Balance");
			System.out.println("3. Show Account Transactions");
			System.out.println("4. Add New Deposite Transaction");
			System.out.println("5. Add New Withdraw Transaction");
			System.out.println("6. Show Account Detail");
			System.out.println("7. Go to Previous Menu");
			System.out.println("Choice : ");
			try {
				choice = Integer.parseInt(sc.nextLine().trim());
				if (choice > 7 || choice < 1) {
					throw new NumberFormatException();
				}
			} catch (NumberFormatException e) {
				System.out.println("Please input a valid choice");
				continue;
			}
			try {
				Transaction temp = new Transaction();
				switch (choice) {
				case 1:
					String inpt = "";
					System.out.println("New Pin :");
					inpt = sc.nextLine().trim();
					if (!validation.valPin(inpt)) {
						throw new exc(exList.NotValidPin);
					}
					this.pin = inpt;
					break;
				case 2:
					System.out.println("Current Balance is : " + this.balance);
					break;
				case 3:
					System.out.println("Account's Transactions");
					for (Transaction trans : this.transactions) {
						System.out.println(trans.toString());
					}
					break;
				case 4:
					System.out.println("case 4");
					temp = Transaction.NewDeposite(this.transactions, sc);
					System.out.println("case 44");
					this.transactions.add(temp);
					System.out.println("case 444");
					this.balance += temp.Amount();
					System.out.println("case 4444");
					break;
				case 5:
					System.out.println("case 5");
					temp = Transaction.NewWithDraw(this.transactions, sc);
					if(temp.Amount() > this.balance) {
						throw new exc(exList.PoorGuyNotEnoughMoney);
					}
					System.out.println("case 55");
					this.transactions.add(temp);
					System.out.println("case 555");
					this.balance -= temp.Amount();
					System.out.println("case 5555");
					break;
				case 6:
					System.out.println(this.toString());
					break;
				case 7:
					getout = true;
					break;
				}
			} catch (Exception e) {
				System.out.println(e);
			}
		}
	}
}
