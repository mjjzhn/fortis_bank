package fortisBank;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

import exceptions.exList;
import exceptions.exc;
import val.validation;

public class Transaction implements Serializable  {
	private static final long serialVersionUID = 1L;
	private String number, desc;
	private Date date;
	private Double amount;
	private TransactionType type;

	public String Number() {
		return this.number;
	}
	public void Number(String c) {
		this.number = c;		
	}
	public String Description() {
		return this.desc;
	}
	public void Description(String c) {
		this.desc = c;		
	}
	

	public Date TransDate() {
		return this.date;
	}
	public void TransDate(Date c) {
		this.date = c;		
	}

	public Double Amount() {
		return this.amount;
	}
	public void Amount(Double c) {
		this.amount = c;		
	}

	public TransactionType Type() {
		return this.type;		
	}
	public void Type(TransactionType c) {
		this.type = c;		
	}
	public Transaction(String num, String desc, Date d, Double amount, TransactionType type) {
		this.number = num;
		this.desc = desc;
		this.date = d;
		this.amount = amount;
		this.type = type;
	}
	public Transaction() {
		
	}
	public String toString() {
		return "Number=" + this.number + ", Description=" + this.desc + ", Date=" + this.date.toString() + ", Amount=" + this.amount.toString() + ", Type=" + this.type.toString();
	}
	
	public static Transaction NewDeposite(ArrayList<Transaction> transList, Scanner sc) {
		System.out.println("New Deposit");
		return NewTransaction(transList, sc, TransactionType.Deposite);
	}
	public static Transaction NewWithDraw(ArrayList<Transaction> transList, Scanner sc) {
		System.out.println("New Withdraw");
		return NewTransaction(transList, sc, TransactionType.Withdraw);
	}
	private static Transaction NewTransaction(ArrayList<Transaction> transList, Scanner sc, TransactionType transType) {
		int num = transList.size();
		while(true) {
			System.out.println("loop");
			try {
				if(!validation.valId(String.valueOf(num))) {
					throw new exc(exList.WrongIdFormat);
				}else if(validation.valDupTransactionId(String.valueOf(num), transList)) {
					throw new exc(exList.DuplicatedId);
				}
				break;
			}catch(Exception e) {
				num++;
			}
		}
		System.out.println("loop out");
		String number = String.valueOf(num);
		String desc = "";
		Double amount = (double) 0;
		int count = 0;
		boolean getout = false;
		System.out.println("loop 2");
		while(!getout) {

			System.out.println("loop 2 in");
			try {
				
				switch(count) {
				case 0:
					System.out.println("Transaction Description :");
					desc = sc.nextLine().trim();
					count++;
				case 1:
					System.out.println("Transaction Amount : ");
					String inpt = sc.nextLine().trim();
					if(!validation.valPosDouble(inpt)) {
						throw new exc(exList.NotValidNumberWithDecimal);
					}
					amount = Double.valueOf(inpt);
					getout = true;
					break;
				}
			}catch(Exception e) {
				System.out.println(e);
			}
		}
		Date temp = new Date();
		return new Transaction(number, desc, new Date(temp.getTime()), amount, transType);
	}
}
